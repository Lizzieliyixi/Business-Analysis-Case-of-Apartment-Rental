rm(list  =  ls())
setwd('/Users/ran/Desktop')
rent <- read.table("ISOM5610Group8_group project_datafile.csv",sep = ',',header = TRUE)
attach(rent)
sum(is.na(rent))
# log transformation
rent$totalRent=log(rent$totalRent)
#将CV转为dummy variables
for (i in 10:20) {
  rent[,i]=as.factor(rent[,i])
}
# 划分数据集
train_set=rent[1:2778,]
valid_set=rent[2779:3572,]
test_set=rent[3573:3968,]
#attach(train_set)
# 将哑变量转化为数值
library("nnet")
lassoset = rent[,1:9]
for (i in 10:20) {
  n=ncol(class.ind(rent[,i]))
  lassoset=cbind(lassoset,class.ind(rent[,i])[,2:n])
}

# Full Model
full.fit=lm(totalRent ~. , data = train_set)
summary(full.fit)
mse_full=mean((exp(predict(full.fit,valid_set))-exp(valid_set[,1]))^2)
mse_full
sqrt(mse_full)
mad_full=mean(abs(exp(predict(full.fit,valid_set))-exp(valid_set[,1])))
mad_full
library(car)
vif(full.fit)
colnames(lassoset)=c('totalRent',names(full.fit$coefficients)[-1])
lasso_train_set=lassoset[1:2778,]
lasso_valid_set=lassoset[2779:3572,]
lasso_test_set=lassoset[3573:3968,]

# Forward Selection
null_m=lm(totalRent~1,data=train_set)
step_var=step(null_m,scope = list(upper=full.fit),direction='forward')
summary(step_var)
# 30个variable
mse_step_var=mean((exp(predict(step_var,valid_set))-exp(valid_set[,1]))^2)
mse_step_var
sqrt(mse_step_var)
mad_step_var=mean(abs(exp(predict(step_var,valid_set))-exp(valid_set[,1])))
mad_step_var
vif(step_var)

# LASSO
# 开始lasso
library(glmnet)
lasso.cv=cv.glmnet(as.matrix(lasso_train_set[-1]), as.matrix(lasso_train_set[,1]),alpha=1,family="gaussian", nfolds=8)
par(mfrow=c(1,1))
plot(lasso.cv) 
plot(glmnet(as.matrix(lasso_train_set[-1]), as.matrix(lasso_train_set[,1]),alpha=1,family="gaussian"),xvar='lambda')
lasso.cv$lambda.min
lasso.cv$lambda.1se
lasso.fit1 = glmnet(as.matrix(lasso_train_set[-1]), as.matrix(lasso_train_set[,1]),alpha=1,family="gaussian",lambda=lasso.cv$lambda.min)
lasso.fit2 = glmnet(as.matrix(lasso_train_set[-1]), as.matrix(lasso_train_set[,1]),alpha=1,family="gaussian",lambda=lasso.cv$lambda.1se)
lasso.fit1$beta
lasso.fit2$beta
summary(lasso.fit1)
mse.lasso1=mean((exp(predict(lasso.cv, s=lasso.cv$lambda.min, as.matrix(lasso_valid_set[-1])))-exp(lasso_valid_set[,1]))^2)
mse.lasso1
sqrt(mse.lasso1)
mad.lasso1=mean(abs(exp(predict(lasso.cv, s=lasso.cv$lambda.min, as.matrix(lasso_valid_set[-1])))-exp(lasso_valid_set[,1])))
mad.lasso1
mse.lasso2=mean((exp(predict(lasso.cv, s=lasso.cv$lambda.1se, as.matrix(lasso_valid_set[-1])))-exp(lasso_valid_set[,1]))^2)
mse.lasso2
sqrt(mse.lasso2)
mad.lasso2=mean(abs(exp(predict(lasso.cv, s=lasso.cv$lambda.1se, as.matrix(lasso_valid_set[-1])))-exp(lasso_valid_set[,1])))
mad.lasso2
# lasso1
lasso1=lm(totalRent~.  -telekomTvOfferON_DEMAND   -conditionmint_condition  , data = lasso_train_set)
summary(lasso1)
vif(lasso1)
# lasso2
lasso2=lm(formula = totalRent ~ telekomUploadSpeed+yearConstructed+livingSpace+livingSpaceRange+conditionfully_renovated+
   lastRefurbish+newlyConstTRUE+balconyTRUE+hasKitchenTRUE+liftTRUE+heatingTypefloor_heating+telekomTvOfferONE_YEAR_FREE+
     conditionmint_condition+conditionrefurbished+interiorQualnormal+interiorQualsimple, data = lasso_train_set)
summary(lasso2)
vif(lasso2)

# PCR
library(pls)
pcr.model=pcr(totalRent~., data = train_set, scale = TRUE, validation = "CV")
summary(pcr.model)
validationplot(pcr.model, val.type="MSEP",legend='topleft')
summary(lm(train_set[,1]~pcr.model$scores[,1:34]))
pcr.fit=pcr(totalRent~.,ncomp=34, data = train_set, scale = TRUE, validation = "CV")
summary(pcr.fit)
mse_pcr=mean((exp(predict(pcr.fit,valid_set,ncomp=34))-exp(valid_set[,1]))^2)
mse_pcr
sqrt(mse_pcr)
mad_pcr=mean(abs(exp(predict(pcr.fit,valid_set,ncomp=34))-exp(valid_set[,1])))
mad_pcr

# adding interaction
names(step_var$coefficients[-1])
interset=cbind(lassoset$totalRent,lassoset[names(step_var$coefficients)[-1]])
colnames(interset)[1]='totalRent'
#     interaction 1
interset1=cbind(interset,interset$noRooms^2)
inter1_train_set=interset1[1:2778,]
inter1_valid_set=interset1[2779:3572,]
inter1_test_set=interset1[3573:3968,]
inter1.fit=lm(totalRent ~. , data = inter1_train_set)
summary(inter1.fit)
mse_inter1=mean((exp(predict(inter1.fit,inter1_valid_set))-exp(inter1_valid_set[,1]))^2)
mse_inter1
sqrt(mse_inter1)
#     interaction 2
interset2=cbind(interset,interset$noRooms*interset$livingSpace)
inter2_train_set=interset2[1:2778,]
inter2_valid_set=interset2[2779:3572,]
inter2_test_set=interset2[3573:3968,]
inter2.fit=lm(totalRent ~. , data = inter2_train_set)
summary(inter2.fit)
mse_inter2=mean((exp(predict(inter2.fit,inter2_valid_set))-exp(inter2_valid_set[,1]))^2)
mse_inter2
sqrt(mse_inter2)
#     interaction 3
interset3=cbind(interset,interset$noRooms*interset$interiorQualnormal)
inter3_train_set=interset3[1:2778,]
inter3_valid_set=interset3[2779:3572,]
inter3_test_set=interset3[3573:3968,]
inter3.fit=lm(totalRent ~. , data = inter3_train_set)
summary(inter3.fit)
mse_inter3=mean((exp(predict(inter3.fit,inter3_valid_set))-exp(inter3_valid_set[,1]))^2)
mse_inter3
sqrt(mse_inter3)

# stacked model
predfull=as.matrix(predict(full.fit,valid_set))
predstep=as.matrix(predict(inter3.fit,inter3_valid_set))
predlasso=predict(lasso.cv, s=lasso.cv$lambda.min, as.matrix(lasso_valid_set[-1]))
predpcr=as.matrix(predict(pcr.fit,valid_set,ncomp=30))
predstack=predfull*0.2+predstep*0.65+predlasso*0.1+predpcr*0.05
mse_stack=mean((exp(predstack)-exp(valid_set[,1]))^2)
sqrt(mse_stack)

# model diagnostic
residuals=inter3.fit$residuals
par(mfrow=c(2,1))
plot(residuals)
library(MASS)
plot(stdres(inter3.fit))
par(mfrow=c(1,1))
plot(stdres(inter3.fit))
abline(2,0,col="red")
abline(-2,0,col="red")
outliers = train_set[abs(stdres(inter3.fit))>2,]
outliers
qqnorm(stdres(inter3.fit))
n=length(inter3.fit$residuals)
plot(inter3.fit$residuals[-n],inter3.fit$residuals[-1])
cor(inter3.fit$residuals[-n],inter3.fit$residuals[-1])

# predict
predtest=exp(predict(inter3.fit,inter3_test_set))
test_res=exp(predict(inter3.fit,inter3_test_set))-exp(inter3_test_set[,1])
mse_test=mean((exp(predict(inter3.fit,inter3_test_set))-exp(inter3_test_set[,1]))^2)
standres=(test_res-mean(test_res))/sqrt(var(test_res))
plot(standres)
abline(2,0,col="red")
abline(-2,0,col="red")
plot(predtest,exp(inter3_test_set[,1]))
abline(0,1,col="red")

names(step_var$coefficients)
names(lasso1$coefficients)
names(lasso2$coefficients)
vif(step_var)
aaa=vif(inter3.fit)
as.data.frame(aaa)

attach(train_set)
onefit=lm(totalRent~ noRooms, data = train_set)
onefit$coefficients[1]
plot(noRooms,totalRent)
abline(onefit$coefficients[1],onefit$coefficients[2],col = 'red')
plot(noRooms^2,totalRent)
cor(totalRent,noRooms)
cor(totalRent,noRooms^2)
